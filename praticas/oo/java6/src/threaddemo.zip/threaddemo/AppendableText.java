interface AppendableText {
  public void append(String s);
}