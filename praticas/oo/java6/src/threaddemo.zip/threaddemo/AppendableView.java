interface AppendableView {
  void setRunning(int i);
  void setStopped(int i);
  AppendableText getTextArea(int i);
}